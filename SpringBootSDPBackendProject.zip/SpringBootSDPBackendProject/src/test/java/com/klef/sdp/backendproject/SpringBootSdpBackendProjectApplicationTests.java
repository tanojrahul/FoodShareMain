package com.klef.sdp.backendproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootSdpBackendProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
