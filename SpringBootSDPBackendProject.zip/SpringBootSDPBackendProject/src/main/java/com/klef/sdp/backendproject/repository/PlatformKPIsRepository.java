package com.klef.sdp.backendproject.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.klef.sdp.backendproject.model.PlatformKPIs;

public interface PlatformKPIsRepository extends JpaRepository<PlatformKPIs, Integer>{

}
