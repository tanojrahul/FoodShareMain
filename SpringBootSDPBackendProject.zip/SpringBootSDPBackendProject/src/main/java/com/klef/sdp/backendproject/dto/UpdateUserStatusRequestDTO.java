package com.klef.sdp.backendproject.dto;

public class UpdateUserStatusRequestDTO {
    private String userId;
    private boolean isActive;

    // Getters and Setters
    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean active) {
        isActive = active;
    }
}
