package com.klef.sdp.backendproject.dto;

public class UpdateDonationStatusRequestDTO {
    private String userId;
    private String status;

    // Getters and Setters
    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}