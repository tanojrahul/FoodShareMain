package com.klef.sdp.backendproject.repository;
import org.springframework.data.jpa.repository.JpaRepository;

import com.klef.sdp.backendproject.model.ImpactMetrics;
public interface ImpactMetricsRepository extends JpaRepository<ImpactMetrics , Integer>{

}
